<?php

require __DIR__ . DIRECTORY_SEPARATOR . 'Wechat' . DIRECTORY_SEPARATOR . 'Loader.php';
